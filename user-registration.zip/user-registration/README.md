# user-registration
In this project, we are holding the data in the front end using LocalStorage.
